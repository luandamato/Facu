# Mini-Analisador-Lexico
Atividade Compiladores N1
