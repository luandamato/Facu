#include <string.h>
#include <iostream>
#include <cstdlib>
#include "Celula.h"

using namespace std;

Celula::Celula(string i) {
	info =  i;
  anterior = NULL;
	prox = NULL;
}

string Celula::getInfo() {
	return info;
}

void Celula::setInfo(string i) {
	info = i;
}

Celula * Celula::getProx() {
	return prox;
}

void Celula::setProx(Celula * p) {
	prox = p;
}
Celula * Celula::getAnterior() {
	return anterior;
}

void Celula::setAnterior(Celula * p) {
	anterior = p;
}
