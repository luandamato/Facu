//#ifndef __CELULA__
//#define __CELULA__
#include <string.h>
#include <iostream>
#ifndef CELULA_H
#define CELULA_H
using namespace std;

class Celula {

	//= privado
	private:
	string info;
	Celula * prox;
  Celula * anterior;

	//= publico
	public:
	Celula(string);
	string  getInfo();
	void setInfo(string);
	Celula * getProx();
	void setProx(Celula * );
  Celula * getAnterior();
	void setAnterior(Celula * );
};
#endif

