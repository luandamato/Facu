

public class Ponto{
   private int x,y;
   public Ponto( int x, int y){
      this.x = x;
      this.y = y;      
   }
   public boolean ehIgual(Ponto p){
      return this.x == p.x && this.y == p.y;      
   }
   public boolean equals(Object outro){
      
   } 
   
   public double distancia(Ponto p){
      double c1 = this.x - p.x;
      double c2 = this.y - p.y;
      double hipotenusa = Math.sqrt(c1*c1 + c2*c2);
      return hipotenusa;
      
   }
   // sobreescrita, polimorfismo
   public String toString(){
      return "("+this.x+","+this.y+")";
      
   }


}