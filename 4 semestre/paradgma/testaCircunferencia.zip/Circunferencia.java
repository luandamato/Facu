public class Circunferencia{
   //(centro(x,y), raio).
   private Ponto centro;
   private double raio;
   public Circunferencia(int x, int y, double raio){
      this.centro = new Ponto( x, y);
      this.raio = raio;
   }
   public Circunferencia(Ponto centro, double raio){
      this.centro = centro;
      this.raio = raio;
   }
   public boolean estaDentro(Ponto p){
      // calcula a distancia do centro da circunferencia para o ponto
      double distancia = centro.distancia(p);
      if( distancia <= this.raio)
         return true;
      else
         return false;
      
   }

   
}