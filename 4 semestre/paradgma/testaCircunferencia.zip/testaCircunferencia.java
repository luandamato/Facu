public class testaCircunferencia{
   public static void main(String args[]){
      Ponto p1 = new Ponto(2,2);
      Circunferencia c1 = new Circunferencia(1,2,2);
      Circunferencia c2 = new Circunferencia(new Ponto(-2,-2),2);
      
      if( c1.estaDentro(p1) )
         System.out.println("esta dentro.");
      else
         System.out.println("esta fora.");
      
      if( c2.estaDentro(p1) )
         System.out.println("esta dentro.");
      else
         System.out.println("esta fora.");

   }
   
}