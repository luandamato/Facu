public class Classe1{
  int Calcula() { return 1; };
  String Metodo1() { return "metodo 1";}
}

