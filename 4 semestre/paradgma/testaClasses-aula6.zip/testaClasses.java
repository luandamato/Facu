public class testaClasses{
   public static void  main( String args[] ){
      Classe2 c2 = new Classe1();
      // ou
      //Classe1 c1 = new Classe2();
      
      if( c1 instanceof Classe2 )
         System.out.println(((Classe2)c1).Metodo2());
      else
         System.out.println(c1.Metodo1());



      
   }
}