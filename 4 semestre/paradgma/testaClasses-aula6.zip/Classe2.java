public class Classe2 extends Classe1 {
  @Override
  int Calcula() { return 2; }
  String Metodo2() { return "metodo 2";}
}